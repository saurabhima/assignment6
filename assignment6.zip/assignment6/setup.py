from distutils.core import setup

setup(
    name='assignment6',
    version='1.0',
    packages=[''],
    url='',
    license='',
    author='saurabhima',
    author_email='saurabhima@gmail.com',
    description=''
)
